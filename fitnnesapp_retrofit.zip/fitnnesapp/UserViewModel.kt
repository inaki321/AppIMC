package mx.edu.up.fitnnesapp


import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import okhttp3.ResponseBody
import retrofit2.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import java.util.stream.DoubleStream.builder
enum class TipoOperacion {
    CONSULTA_EXITOSA, ERROR
}
data class Usuario(val nombre:String,val apellido:String,val genero:Boolean)
interface Directorio
{
    @POST("registrarPersona")
    fun agregarPersona(@Body usuario:Usuario):Call<ResponseBody>
    @GET("personas")
    fun getPersonas():Call<List<Usuario>>
}
enum class Estado{
    ERROR,
    TODO_OK
}
data class EventoDirectorio(val estado:Estado,val listaUsuarios:List<Usuario>?,val error:String?=null)
class UserViewModel:ViewModel() {
    val userLiveData =  MutableLiveData<UserViewModel>()
    lateinit var retrofit: Retrofit
    lateinit var usuarios: UserViewModel
    var userReg by mutableStateOf("")
    var pwd by mutableStateOf("")
    var nameReg by mutableStateOf("")
    var apellidoReg by mutableStateOf("")
    var edadReg by mutableStateOf("")
    var generoReg by mutableStateOf("")
    var pesoReg by mutableStateOf("")
    var estatura by mutableStateOf("")
    var pesoD by mutableStateOf("")
    var ejercita by mutableStateOf(false)
    var klCalorias by mutableStateOf(0)

    init {
        retrofit = Retrofit.Builder()
            .baseUrl("http://localhost/serverApps.php")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        usuarios = retrofit.create<UserViewModel>()
    }
    fun getArticulos()
    {
        usuarios.getArticulos().enqueue(object:Callback<List<UserViewModel>>{
            override fun onResponse(call: Call<List<UserViewModel>>, response: Response<List<UserViewModel>>) {
                userLiveData.postValue(Usuario(TipoOperacion.CONSULTA_EXITOSA,response.body()))

            }

            override fun onFailure(call: Call<List<UserViewModel>>, t: Throwable) {
                Log.e("ViewModel","ViewModel cannot execute API call",t)
                userLiveData.postValue(Usuarios(TipoOperacion.ERROR))
            }

        })

    }

    fun setUser(newUser: String){
        userReg = newUser
    }

    fun setPassword(newPwd: String){
        pwd = newPwd
    }

    fun setNombre(newName:String){
        nameReg = newName
    }
    fun setApellido(newApellido:String){
        apellidoReg = newApellido
    }
    fun setEdad(newAge:String){
        edadReg = newAge
    }
    fun setGenero(newGen:String){
        generoReg = newGen
    }
    fun setPeso(newPeso:String){
        pesoReg = newPeso
    }
    fun setAltura(newAltura:String){
        estatura = newAltura
    }
    fun setEjericio(newEjercicio:Boolean){
        ejercita = newEjercicio
    }
    fun setpesoD(newPesoD:String){
        pesoD = newPesoD
    }
    fun setCalorias(newCaloria:Int){
        klCalorias += newCaloria
    }
    fun resetCalorias(reset:Int){
        klCalorias = 0
    }
}